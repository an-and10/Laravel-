;


<?php $__env->startSection('content'); ?>

<h1>Project-id <?php echo e($project->id); ?> </h1>


<a href="\projects\<?php echo e($project->id); ?>\edit">Edit Details</a>



<div class="container">


	<?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<form method="POST" action ="/tasks/<?php echo e($task->id); ?>">
			
			<?php echo method_field('PATCH'); ?>
			<?php echo csrf_field(); ?>
						<label for="completed" class="checkbox">
				<input type="checkbox" name="completed" onChange="this.form.submit()">
				<?php echo e($task->description); ?>  <br>   <?php echo e($task->project_id); ?></li>
		</form>

	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<br>
<br>


<form method="POST" action="/projects/<?php echo e($project->id); ?>/tasks">
<?php echo csrf_field(); ?>

	<label for="description"> Add New Task</label>
		<input name="description" placeholder="Add Description"  >


		<button type="submit">Add Task</button>


</form>


 	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 	<li><?php echo e($errors); ?></li>

 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\resources\views/projects/show.blade.php ENDPATH**/ ?>