;


<?php $__env->startSection('content'); ?>

<h1>Edit Form </h1>


<form method="POST" action="/projects/<?php echo e($project->id); ?>">

	<?php echo e(method_field('PATCH')); ?>

	<?php echo e(csrf_field()); ?>


	<label for="name">Name</label>
	<input type="text" name="name" placeholder="Edit Name" value ="<?php echo e($project->name); ?>">

	<label for =lastname>Last </label>
	<input type="text" name="lastname" placeholder="Edit Lastname" value ="<?php echo e($project->lastname); ?>">

	<button  type="submit" >Update recored</button>
</form>


<form method="POST" action="/projects/<?php echo e($project->id); ?>">

	<?php echo e(method_field('DELETE')); ?>

	<?php echo e(csrf_field()); ?>


	<button  type="submit" >Delete recored</button>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\resources\views/projects/edit.blade.php ENDPATH**/ ?>