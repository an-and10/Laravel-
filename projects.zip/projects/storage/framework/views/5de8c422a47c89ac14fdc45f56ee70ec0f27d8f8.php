<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>

	<link type="stylesheet" href="bulma/css/bulma.css">
</head>
<body>

		<div class="container">
			<?php echo $__env->yieldContent('content'); ?>;

		</div>


</body>
</html><?php /**PATH C:\xampp\htdocs\projects\resources\views/layout.blade.php ENDPATH**/ ?>