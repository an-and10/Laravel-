<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<h1> My Project here</h1>.

<ul>

<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<a href="\projects\<?php echo e($project->id); ?>"><li><?php echo e($project->name); ?></li></a>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</ul>

</body>
</html><?php /**PATH C:\xampp\htdocs\projects\resources\views/projects/index.blade.php ENDPATH**/ ?>