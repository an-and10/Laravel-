<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<h1>My New Projects</h1>.
 <form method="POST" action ="/projects">
 	<?php echo e(csrf_field()); ?>

 	<center>
 		<input type="text" name="name" placeholder='Enter Name' value="  <?php echo e(old('name')); ?>">
 		<input type="text" name="lastname" placeholder='Enter Lastname' value =" <?php echo e(old('lastname')); ?>" >
 		<button type="submit">Submit</button>
 	</center>
 </form>


 <div class="container">

 	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 	<li><?php echo e($errors); ?></li>

 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\projects\resources\views/projects/create.blade.php ENDPATH**/ ?>