<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>

	<link type="stylesheet" href="bulma/css/bulma.css">


</head>
<body>

		<div class="container">
			@yield('content');

		</div>



		
</body>
</html>