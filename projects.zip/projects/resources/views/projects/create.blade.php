<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<h1>My New Projects</h1>.
 <form method="POST" action ="/projects">
 	{{	csrf_field() }}
 	<center>
 		<input type="text" name="name" placeholder='Enter Name' value="  {{ old('name') }}">
 		<input type="text" name="lastname" placeholder='Enter Lastname' value =" {{ old('lastname') }}" >
 		<button type="submit">Submit</button>
 	</center>
 </form>


 <div class="container">

 	@foreach($errors->all() as $errors)

 	<li>{{ $errors}}</li>

 	@endforeach
 </div>

</body>
</html>