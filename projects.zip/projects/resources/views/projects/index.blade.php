<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<h1> My Project here</h1>.

<ul>

@foreach ($projects as $project)

<a href="\projects\{{$project->id}}"><li>{{$project->name}}</li></a>


@endforeach


</ul>

</body>
</html>