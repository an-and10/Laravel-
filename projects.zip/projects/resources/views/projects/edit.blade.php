

@extends('layout');


@section('content')

<h1>Edit Form </h1>


<form method="POST" action="/projects/{{$project->id}}">

	{{ method_field('PATCH')}}
	{{	csrf_field() }}

	<label for="name">Name</label>
	<input type="text" name="name" placeholder="Edit Name" value ="{{ $project->name }}">

	<label for =lastname>Last </label>
	<input type="text" name="lastname" placeholder="Edit Lastname" value ="{{ $project->lastname }}">

	<button  type="submit" >Update recored</button>
</form>


<form method="POST" action="/projects/{{$project->id}}">

	{{ method_field('DELETE')}}
	{{	csrf_field() }}

	<button  type="submit" >Delete recored</button>

</form>
@endsection