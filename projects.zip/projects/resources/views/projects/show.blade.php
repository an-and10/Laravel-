
@extends('layout');


@section('content')

<h1>Project-id {{$project->id}} </h1>


<a href="\projects\{{$project->id}}\edit">Edit Details</a>



<div class="container">


	@foreach($project->tasks as $task)

		<form method="POST" action ="/tasks/{{$task->id}}">
			
			@method ('PATCH')
			@csrf
						<label for="completed" class="checkbox">
				<input type="checkbox" name="completed" onChange="this.form.submit()">
				{{ $task->description }}  <br>   {{ $task->project_id }}</li>
		</form>

	
	@endforeach


<br>
<br>


<form method="POST" action="/projects/{{ $project->id }}/tasks">
@csrf

	<label for="description"> Add New Task</label>
		<input name="description" placeholder="Add Description"  >


		<button type="submit">Add Task</button>


</form>


 	@foreach($errors->all() as $errors)

 	<li>{{ $errors}}</li>

 	@endforeach

@endsection