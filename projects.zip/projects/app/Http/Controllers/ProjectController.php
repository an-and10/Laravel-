<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\project;

class ProjectController extends Controller
{
    public function index()
    {


    	$projects= project::all();


    	
    	return view('projects.index',compact('projects'));
    } 

    public function show(project $project)
    {
        

        return view('projects.show',compact('project'));
    }

     public function create()
    {


    	$projects= project::all();


    	
    	return view('projects.create');
    }

//THIS FUNCTION IS THEIR FOR FORM VALIDATION AND MINMIUM CHARACTER IN THE INPUT FORM//
     public function store(project $project)
    {



        //Inportyant to note about form validation///
    		$userdata= request()->validate([
            'name'=> ['required','min:3','max:7'],
            'lastname'=> ['required', 'min:1','max:12']

            ]);

    		project::create($userdata);

    		return redirect('/projects');

    		    		

    }

    public function edit(project $project)
    {	
    		
    		 return view('projects.edit',compact('project'));
    }

    public function update(project $project)

	{

		$project->update(request(['name','lastname']));
		
		return redirect('/projects');

	}

	public function destroy(project $project)

	{
        $project->delete();
        return redirect('/projects');
	}

}

