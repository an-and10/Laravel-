<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use App\project;

class ProjectTaskController extends Controller
{
   public function store(project $project)
   {	

   	

   		$project->addTask(request()->validate(['description' =>'required']));
   /*	Task::create([

   			'project_id' => $project->id,
   			'description' => request('description')

   	]);*/


   	return back();
   }

   public function update(Task $task)
   {
   		$task->update([
   			'completed'=> request()->has('completed')
   		]);

   		return back();
   }
}
