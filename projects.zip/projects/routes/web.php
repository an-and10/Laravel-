<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Route::resource('projects','ProjectController');

Auth::routes();
Route::post('/projects/{project}/tasks','ProjectTaskController@store');
Route::patch('/tasks/{task}','ProjectTaskController@update');

/*
Route::get('/projects','ProjectController@index');

Route::post('/projects','ProjectController@store');


Route::post('/projects/{project}','ProjectController@show');


Route::get('/projects/create','ProjectController@create');

Route::post('/projects/{project}/edit','ProjectController@edit');


Route::patch('/projects/{project}','ProjectController@update');

Route::delete('/projects/{project}','ProjectController@destroy');
*/
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
